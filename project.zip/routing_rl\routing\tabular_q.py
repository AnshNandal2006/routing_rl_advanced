"""Improved tabular Q-Learning with loop avoidance and shaped rewards."""
from __future__ import annotations
import random
from typing import Dict, Optional, Tuple, List, Any
from .base import RoutingPolicy
from routing_rl.network.packet import Packet
from routing_rl.network.router import Router


class TabularQPolicy(RoutingPolicy):
    def __init__(
        self,
        routers,
        links,
        alpha: float = 0.15,
        gamma: float = 0.92,
        epsilon: float = 0.25,
        reward_cfg: Optional[Dict] = None,
    ):
        super().__init__(routers, links, reward_cfg)
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = 0.02
        self.epsilon_decay = 0.9992
        self.q_table: Dict[Tuple[str, str, int], Dict[str, float]] = {}
        self.updates = 0
        self.explorations = 0

        # Reward coefficients
        rc = self.reward_cfg
        self.r_hop = rc.get("hop_penalty", -1.0)
        self.r_queue = rc.get("queue_penalty_scale", -2.5)
        self.r_delivery = rc.get("delivery_bonus", 40.0)
        self.r_drop = rc.get("drop_penalty", -60.0)

    def _get_q(self, state: Tuple, action: str) -> float:
        return self.q_table.get(state, {}).get(action, 0.0)

    def _set_q(self, state: Tuple, action: str, value: float) -> None:
        if state not in self.q_table:
            self.q_table[state] = {}
        self.q_table[state][action] = value

    def _update_q(
        self,
        state,
        action,
        reward,
        next_state,
        next_actions: List[str],
    ) -> None:
        q = self._get_q(state, action)
        max_next = max((self._get_q(next_state, a) for a in next_actions), default=0.0)
        target = reward + self.gamma * max_next
        self._set_q(state, action, q + self.alpha * (target - q))
        self.updates += 1

    def select_next_hop(
        self, packet: Packet, router: Router, now: float
    ) -> Optional[str]:
        valid = [
            n
            for n in router.neighbors
            if self.links.get((router.id, n)) and self.links[(router.id, n)].is_up
        ]
        # Strong loop avoidance
        unvisited = [a for a in valid if a not in packet.path]
        if unvisited:
            valid = unvisited
        if not valid:
            return None

        state = (router.id, packet.dst, router.queue_level())
        if random.random() < self.epsilon:
            next_hop = random.choice(valid)
            self.explorations += 1
        else:
            q_vals = {a: self._get_q(state, a) for a in valid}
            max_q = max(q_vals.values())
            best = [a for a, q in q_vals.items() if q == max_q]
            next_hop = random.choice(best)

        packet.pending_state = state
        packet.pending_action = next_hop
        packet.pending_router = router.id
        return next_hop

    def on_hop_forward(
        self, packet: Packet, router_id: str, next_hop: str, now: float
    ) -> None:
        next_r = self.routers[next_hop]
        next_state = (next_hop, packet.dst, next_r.queue_level())
        next_valid = [
            n
            for n in next_r.neighbors
            if self.links.get((next_hop, n)) and self.links[(next_hop, n)].is_up
        ]
        reward = self.r_hop + self.r_queue * next_r.queue_level()
        if packet.is_priority:
            reward *= 1.15  # slightly stronger signal for priority
        if packet.pending_state is not None and packet.pending_action is not None:
            self._update_q(
                packet.pending_state,
                packet.pending_action,
                reward,
                next_state,
                next_valid,
            )
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def on_packet_delivered(self, packet: Packet, now: float) -> None:
        if packet.pending_state is not None and packet.pending_action is not None:
            bonus = self.r_delivery
            if packet.is_priority:
                bonus *= 1.3
            self._update_q(
                packet.pending_state,
                packet.pending_action,
                bonus,
                None,
                [],
            )

    def on_packet_dropped(self, packet: Packet, reason: str, now: float) -> None:
        if packet.pending_state is not None and packet.pending_action is not None:
            self._update_q(
                packet.pending_state,
                packet.pending_action,
                self.r_drop,
                None,
                [],
            )

    def get_stats(self) -> Dict[str, Any]:
        return {
            "q_entries": sum(len(v) for v in self.q_table.values()),
            "updates": self.updates,
            "explorations": self.explorations,
            "epsilon": self.epsilon,
        }
